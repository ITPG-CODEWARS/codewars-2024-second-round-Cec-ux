<?php 

include '../db.php';

// Connect to the database
$db = new Database("localhost", "url_short", "root", "root");
$db = $db->connect();

// Retrieve the short URL from the GET request
$short_url = isset($_GET['delete']) ? trim($_GET['delete']) : '';

// Check if short_url is provided
if ($short_url !== '') {
    // Look up the URL's ID using the short URL
    $query = "SELECT id FROM urls WHERE short_url = :short_url";
    $stmt = $db->prepare($query);
    $stmt->execute(array("short_url" => $short_url));
    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($row) {
        // If the short URL exists, delete the entry
        $id = $row['id'];
        $deleteQuery = "DELETE FROM urls WHERE id = :id";
        $deleteStmt = $db->prepare($deleteQuery);
        $deleteStmt->execute(array("id" => $id));

        // Redirect to the main page with a success message
        header("location: /?msg=deleted");
    } else {
        // Redirect with an error message if the short URL wasn't found
        header("location: /?msg=not_found");
    }
} else {
    // Redirect with an error message if no short URL was provided
    header("location: /?msg=missing_url");
}
exit();